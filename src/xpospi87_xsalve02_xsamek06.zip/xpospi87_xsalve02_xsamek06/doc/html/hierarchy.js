var hierarchy =
[
    [ "Main", "classMain.html", null ],
    [ "Model.MathLib", "classModel_1_1MathLib.html", null ],
    [ "View.SwingGui", "classView_1_1SwingGui.html", null ],
    [ "ActionListener", null, [
      [ "Controller.Controller", "classController_1_1Controller.html", null ]
    ] ]
];