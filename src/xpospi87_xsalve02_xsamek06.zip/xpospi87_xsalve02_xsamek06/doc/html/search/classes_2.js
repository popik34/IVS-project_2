var searchData=
[
  ['swinggui',['SwingGui',['../classView_1_1SwingGui.html',1,'View']]]
];
