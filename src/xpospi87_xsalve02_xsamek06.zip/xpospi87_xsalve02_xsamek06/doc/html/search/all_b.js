var searchData=
[
  ['reciprocal',['reciprocal',['../classModel_1_1MathLib.html#ab6af980980c470c06fd2e903e7567a45',1,'Model::MathLib']]],
  ['root',['root',['../classModel_1_1MathLib.html#a7d3447244ef027fcb2f6e428ebc65293',1,'Model::MathLib']]]
];
