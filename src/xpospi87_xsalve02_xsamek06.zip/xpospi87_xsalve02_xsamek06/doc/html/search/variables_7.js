var searchData=
[
  ['view',['view',['../classController_1_1Controller.html#aa418da22d4f44a7242ab320e23af8328',1,'Controller::Controller']]]
];
