var searchData=
[
  ['mainframe',['mainFrame',['../classView_1_1SwingGui.html#af1e0eeff3d2969ddbb08169d30130cfe',1,'View::SwingGui']]],
  ['mainpanel',['mainPanel',['../classView_1_1SwingGui.html#a7bcec67fc4c96b388aeff2714504e55a',1,'View::SwingGui']]]
];
