var searchData=
[
  ['buttons',['buttons',['../classView_1_1SwingGui.html#a4a20b546cf799c98c89990dd93435b27',1,'View::SwingGui']]]
];
