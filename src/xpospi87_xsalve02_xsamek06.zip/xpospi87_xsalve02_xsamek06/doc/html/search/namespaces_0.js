var searchData=
[
  ['controller',['Controller',['../namespaceController.html',1,'']]]
];
