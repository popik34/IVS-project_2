var searchData=
[
  ['view',['View',['../namespaceView.html',1,'View'],['../classController_1_1Controller.html#aa418da22d4f44a7242ab320e23af8328',1,'Controller.Controller.view()']]]
];
