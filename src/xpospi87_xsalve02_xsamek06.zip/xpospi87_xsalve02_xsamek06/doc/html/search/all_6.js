var searchData=
[
  ['getbuttons',['getButtons',['../classView_1_1SwingGui.html#afa943fb498fddf65a58fd3bf90f1c1a8',1,'View::SwingGui']]],
  ['getstatementfield',['getStatementField',['../classView_1_1SwingGui.html#a3fae49b66d65cc1f74451174a64bb1ef',1,'View::SwingGui']]],
  ['gettextfield',['getTextField',['../classView_1_1SwingGui.html#aa680291379ff5ec45c17d3329bc9fd51',1,'View::SwingGui']]]
];
