var namespaces =
[
    [ "Controller", "namespaceController.html", null ],
    [ "Model", "namespaceModel.html", null ],
    [ "View", "namespaceView.html", null ]
];