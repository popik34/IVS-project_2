var annotated =
[
    [ "Controller", "namespaceController.html", "namespaceController" ],
    [ "Model", "namespaceModel.html", "namespaceModel" ],
    [ "View", "namespaceView.html", "namespaceView" ],
    [ "Main", "classMain.html", "classMain" ]
];