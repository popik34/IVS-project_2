var namespaceView =
[
    [ "SwingGui", "classView_1_1SwingGui.html", "classView_1_1SwingGui" ]
];